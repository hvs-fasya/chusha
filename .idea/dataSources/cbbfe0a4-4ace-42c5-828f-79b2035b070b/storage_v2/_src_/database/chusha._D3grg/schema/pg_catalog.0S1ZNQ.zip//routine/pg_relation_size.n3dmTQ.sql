create function pg_relation_size(regclass)
  returns bigint
strict
cost 1
language sql
as $$
select pg_catalog.pg_relation_size($1, 'main')
$$;

