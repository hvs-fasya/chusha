create function rpad(text, integer)
  returns text
immutable
strict
cost 1
language sql
as $$
select pg_catalog.rpad($1, $2, ' ')
$$;

