create function textanycat(text, anynonarray)
  returns text
stable
strict
cost 1
language sql
as $$
select $1 || $2::pg_catalog.text
$$;

